var searchData=
[
  ['prime_20number_20check_20by_20shekar_20jk_0',['Prime Number check by Shekar Jk',['../index.html',1,'']]],
  ['primenumber_1',['primenumber',['../primenumber_8h.html#ae59cf1e971ce1cb907879921a85b28de',1,'primenumber.h']]],
  ['primenumber_2eh_2',['primenumber.h',['../primenumber_8h.html',1,'']]]
];
