var searchData=
[
  ['prime_20number_20check_20by_20shekar_20jk_5',['Prime Number check by Shekar Jk',['../index.html',1,'']]]
];
