var searchData=
[
  ['primenumber_2eh_3',['primenumber.h',['../primenumber_8h.html',1,'']]]
];
