var searchData=
[
  ['primenumber_4',['primenumber',['../primenumber_8h.html#ae59cf1e971ce1cb907879921a85b28de',1,'primenumber.h']]]
];
