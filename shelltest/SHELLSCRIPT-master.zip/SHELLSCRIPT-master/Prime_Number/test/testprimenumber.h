
#ifndef __TESTPRIMENUMBER_H__
#define __TESTPRIMENUMBER_H__

int test_main(void);

#endif /* #ifndef __TESTPRIMENUMBER_H__ */
